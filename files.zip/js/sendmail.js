$("#contactform").submit(function(e) {
    e.preventDefault(); //prevent default action 
    proceed = true;
    var name = $("#name").val();
    var email = $("#email").val();
    var subject = $("#subject").val();
    var message = $("#msg").val();
    var file = $("#uploadfile").val();

    
    $('#uploadfile').setProgressedUploader({
        onInit: function (elements) {
            // triggered on init
        },

        onGetFile: function (elements) {
            // triggered on get file
        },

        onStartSubmitting: function (elements) {
            // triggered when starting uploading
        },

        onProcessing: function (elements) {
            // triggered when processing
        },

        onFinish: function (elements, data) {
            var form_data = new FormData(this);

            $.ajax({
                type: "POST",
                url: "mail.aspx",
                processData: false,
                contentType: false,
                cache: false,
                data: form_data,
                success: function () {
                    $('#contactform').html("<div id='message'></div>");
                    $('#message').html("<h2>Message Submitted!We will contact you soon!</h2>").append("<p>We will be in touch soon.</p>").hide().fadeIn(1500, function () {
                        $('#message').append(" <img id='checkmark' src='jpg/check.png' width='100' height=100' />");
                    });
                }
            });
            return false;
        },

        onError: function (e) {
            // triggered on error
        }
    });
  

   

});